package com.kueche.persistenz;

public interface MyInterface {
	void blinken();
	void blinkenAus();
}

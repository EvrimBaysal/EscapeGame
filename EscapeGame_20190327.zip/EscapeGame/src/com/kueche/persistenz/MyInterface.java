package com.kueche.persistenz;

/** Interface blinken() Blinken ausw�hlt Gegenstand */
public interface MyInterface {
	void blinken();
	void blinkenAus();
}
